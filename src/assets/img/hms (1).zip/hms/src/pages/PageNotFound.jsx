import React from 'react'

function PageNotFound() {
  return (
    <>PageNotFound</>
  )
}

export default PageNotFound