import React from 'react'

function BookAppointment() {
    return (
        <>
            <div className="pc-container">
                <div className="pc-content">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="card">
                                <div className="card-header">
                                    <h5>Book Appointment</h5>
                                </div>
                                <div className="card-body">
                                    <form>
                                        {/* <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Treatment ID:</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="T001" />
                                        </div> */}
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Specialization:</label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Dentist</option>
                                                <option value="1">Cardiologist</option>
                                                <option value="2">Neurologist</option>
                                                <option value="3">Gynecologist</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Specialization:</label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Mark</option>
                                                <option value="1">Jacob</option>
                                                <option value="2">Larry</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Consultancy Fees:</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" readOnly placeholder="500" />
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Appointment Date:</label>
                                            <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="3000 Rs" />
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Appointment Time:</label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>8:00 AM to 9:00 AM</option>
                                                <option>9:00 AM to 10:00 AM</option>
                                                <option>10:00 AM to 11:00 AM</option>
                                                <option>11:00 AM to 12:00 PM</option>
                            
                                            </select>
                                        </div>
                                        <button className='btn btn-primary'>Make Appointment</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default BookAppointment