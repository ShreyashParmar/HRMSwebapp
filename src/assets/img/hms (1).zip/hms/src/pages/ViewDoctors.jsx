import React from 'react'

function ViewDoctors() {
    return (
        <>
            <div className="pc-container">
                <div className="pc-content">
                    {/* [ breadcrumb ] start */}

                    {/* [ breadcrumb ] end */}
                    {/* [ Main Content ] start */}
                    <div className="row">
                        {/* [ sample-page ] start */}
                        <div className="col-sm-12">
                            <div className="card">
                                <div className="card-header">
                                    <h5>View Doctors</h5>
                                </div>
                                <div className="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr className='font-bold'>
                                                <th scope="col">Doctor #ID</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Specialization</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Fees</th>
                                            </tr>
                                        </thead>
                                        <tbody >
                                            <tr>
                                                <th scope="row">DOC001</th>
                                                <td>Mark</td>
                                                <td>Dentist</td>
                                                <td>mark@gmail.com</td>
                                                <td>500</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">DOC002</th>
                                                <td>Jacob</td>
                                                <td>Cardiologist</td>
                                                <td>jacob@gmail.com</td>
                                                <td>600</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">DOC003</th>
                                                <td>Larry</td>
                                                <td>Neurologist</td>
                                                <td>larry@gmail.com</td>
                                                <td>800</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                        {/* [ sample-page ] end */}
                    </div>
                    {/* [ Main Content ] end */}
                </div>
            </div>
        </>
    )
}

export default ViewDoctors