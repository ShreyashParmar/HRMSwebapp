import React from 'react'

function ViewAppointments() {
  return (
    <>
        <div className="pc-container">
                <div className="pc-content">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="card">
                                <div className="card-header">
                                    <h5>View Appointments</h5>
                                </div>
                                <div className="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr className='font-bold'>
                                                <th scope="col">#ID</th>
                                                <th scope="col">Patient</th>
                                                <th scope="col">Gender</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Contact</th>
                                                <th scope="col">Date</th>
                                                <th scope="col">Time</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Action</th>
                                                <th scope="col">Prescription</th>
                                            </tr>
                                        </thead>
                                        <tbody >
                                            <tr>
                                                <th scope="row">1</th>
                                                <td>Priya</td>
                                                <td>Female</td>
                                                <td>priya@gmail.com</td>
                                                <td>7990456979</td>
                                                <td>12/01/2024</td>
                                                <td>9:00 AM to 10:00 AM</td>
                                                <td>Active</td>
                                                <td><button className='btn btn-danger'>Cancel</button></td>
                                                <td><button className='btn btn-success'>Prescribe</button></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">2</th>
                                                <td>Aman</td>
                                                <td>Male</td>
                                                <td>aman@gmail.com</td>
                                                <td>9409068987</td>
                                                <td>12/01/2024</td>
                                                <td>9:00 AM to 10:00 AM</td>
                                                <td>Active</td>
                                                <td><button className='btn btn-danger'>Cancel</button></td>
                                                <td><button className='btn btn-success'>Prescribe</button></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                       
                    </div>
           
                </div>
            </div>
    </>
  )
}

export default ViewAppointments