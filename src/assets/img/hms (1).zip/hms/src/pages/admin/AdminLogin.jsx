import React, { useState } from 'react';

function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = () => {
    // Implement your sign-in logic here
    console.log('Username:', username);
    console.log('Password:', password);
    // You may want to make API calls or perform authentication logic
  };

  return (
    <>
      <div className="auth-main">
        <div className="auth-wrapper v3">
          <div className="auth-form">
            <div className="card my-5">
              <div className="card-body">
                <div className="row">
                  <div className="d-flex justify-content-center">
                    <div className="auth-header">
                      <h2 className="text-secondary mt-5"><b>Hi Admin, Welcome Back</b></h2>
                      <p className="f-16 mt-2">Enter your credentials to continue</p>
                    </div>
                  </div>
                </div>
                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    id="floatingUsername"
                    placeholder="Email address / Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                  <label htmlFor="floatingUsername">Username</label>
                </div>
                <div className="form-floating mb-3">
                  <input
                    type="password"
                    className="form-control"
                    id="floatingPassword"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <label htmlFor="floatingPassword">Password</label>
                </div>
                <div className="d-grid mt-4">
                  <button type="button" className="btn btn-secondary" onClick={handleSignIn}>
                    Sign In
                  </button>
                </div>
                <hr />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AdminLogin;
