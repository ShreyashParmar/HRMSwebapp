import {addDoc,collection} from 'firebase/firestore'
import React,{useState} from 'react'
import {db } from '../../firebaseconfig'
import { toast } from 'react-toastify';

function AdminAddDoctor() {
    let [nm,setNm]=useState()
    let [unm,setUnm]=useState()
    let [specialization,setSpecialization]=useState()
    let [email,setEmail]=useState()
    let [pwd,setPwd]=useState()
    let [fees,setFees]=useState()

    async function addDoctor(e){
        e.preventDefault()

        let colref = collection(db,"doctors")
        

        await addDoc(colref,{
            "nm":nm,
            "unm":unm,
            "specialization":specialization,
            "email":email,
            "pwd":pwd,
            "fees":fees,
        })

        toast("Doctor Saved")
    }
  return (
   <>
   
   <div className="pc-container">
                <div className="pc-content">
                    {/* [ breadcrumb ] start */}
                    {/* [ breadcrumb ] end */}
                    {/* [ Main Content ] start */}
                    <div className="row">
                        {/* [ sample-page ] start */}
                        <div className="col-sm-12">
                            <div className="card">
                                <div className="card-header">
                                    <h5>Add Doctor</h5>
                                </div>
                                <div className="card-body">
                                    <form onSubmit={addDoctor} >
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Doctor Name</label>
                                            <input type="text" onChange={(e)=>setNm(e.target.value)} class="form-control" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleFormControlInput1" className="form-label">User Name</label>
                                            <input type="text" onChange={(e)=>setUnm(e.target.value)} className="form-control"  />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleFormControlInput1" className="form-label">Specialization</label>
                                           <select className='form-select' name='' id='' onChange={(e)=>setSpecialization(e.target.value)}>
                                            <option value="Dentist">Dentist</option>
                                            <option value="physician">Physician</option>
                                           </select>
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleFormControlInput1" className="form-label">Email</label>
                                            <input type="text" onChange={(e)=>setEmail(e.target.value)} className="form-control"  />
                                        </div>

                                        <div className="mb-3">
                                            <label htmlFor="exampleFormControlInput1" className="form-label">Password</label>
                                            <input type="text" onChange={(e)=>setPwd(e.target.value)} className="form-control"  />
                                        </div>

                                        <div className="mb-3">
                                            <label htmlFor="exampleFormControlInput1" className="form-label">Consultancy Fees</label>
                                            <input type="text" onChange={(e)=>setFees(e.target.value)} className="form-control"  />
                                        </div>
                                        <button className='btn btn-primary'>Add Doctor</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        {/* [ sample-page ] end */}
                    </div>
                    {/* [ Main Content ] end */}
                </div>
            </div>
   
   
   </>
  )
}

export default AdminAddDoctor