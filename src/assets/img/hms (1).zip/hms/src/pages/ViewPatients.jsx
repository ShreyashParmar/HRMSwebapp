import React from 'react'

function ViewPatients() {
  return (
    <>
      <div className="pc-container">
                <div className="pc-content">
                    <div className="row">
                        {/* [ sample-page ] start */}
                        <div className="col-sm-12">
                            <div className="card">
                                <div className="card-header">
                                    <h5>View Patients</h5>
                                </div>
                                <div className="card-body">
                                 
                                </div>
                            </div>
                        </div>
                        {/* [ sample-page ] end */}
                    </div>
                    {/* [ Main Content ] end */}
                </div>
            </div>
    </>
  )
}

export default ViewPatients