import React from 'react'

function AddPrescription() {
    return (
        <>
            <div className="pc-container">
                <div className="pc-content">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="card">
                                <div className="card-header">
                                    <h5>Add Prescription</h5>
                                </div>
                                <div className="card-body">
                                    <form>
                                        {/* <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Treatment ID:</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="T001" />
                                        </div> */}
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Diseases:</label>
                                            <textarea className='form-control' name="" id="" cols="30" rows="4"></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Allergies:</label>
                                            <textarea className='form-control' name="" id="" cols="30" rows="4"></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Prescription:</label>
                                            <textarea className='form-control' name="" id="" cols="30" rows="4"></textarea>
                                        </div>
                                        <button className='btn btn-primary'>Add Prescription</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default AddPrescription
