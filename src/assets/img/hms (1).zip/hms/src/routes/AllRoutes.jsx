import {Routes,Route} from 'react-router-dom'
import Dashboard from '../pages/admin/AdminDashboard'
// import Login from '../pages/Login'
import Register from '../pages/patient/PatientRegister'
import ViewDoctors from '../pages/ViewDoctors'
import ViewPatients from '../pages/ViewPatients'
import AdminLogin from '../pages/admin/AdminLogin'
import PageNotFound from '../pages/PageNotFound'
import PatientRegister from '../pages/patient/PatientRegister'
import BookAppointment from '../pages/patient/PatientBookAppointment'
import PatientLogin from '../pages/patient/PatientLogin'
import AppointmentHistory from '../pages/patient/PatientAppointmentHistory'
import ViewAppointments from '../pages/doctor/DoctorViewAppointments'
import AddPrescription from '../pages/AddPrescription'
import AdminDashboard from '../pages/admin/AdminDashboard'


export function AllRoutes(){
    return(
        <>
    <Routes>
      <Route path= '/' element = { <Dashboard/>} />
      <Route path= 'adminlogin' element = { <AdminLogin/>} />
      <Route path= 'patientregister' element = { <PatientRegister/>} />
      <Route path= 'patientlogin' element = { <PatientLogin/>} />
      <Route path= 'register' element = { <Register/>} />
    
      <Route path= 'appointmenthistory' element = { <AppointmentHistory/>} />
      <Route path= 'viewappointment' element = { <ViewAppointments/>} />
      <Route path= 'addprescription' element = { <AddPrescription/>} />
    
      <Route path= 'bookappoitment' element = { <BookAppointment/>} />
      <Route path= 'viewpatients' element = { <ViewPatients/>} />
      <Route path= 'viewdoctors' element = { <ViewDoctors/>} />
      <Route path= 'admindashboard' element = { <AdminDashboard/>} />
      <Route path= '*' element = { <PageNotFound/>} />
  
     </Routes>
        </>
    )
} 