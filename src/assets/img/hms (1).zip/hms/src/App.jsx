import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

import Header from './components/Header'
import Sidebar from './components/Sidebar'
import { AllRoutes } from './routes/AllRoutes'
import AdminAddDoctor from './pages/admin/AdminAddDoctor'
import AdminLogin from './pages/admin/AdminLogin'
import DoctorViewAppointments from './pages/doctor/DoctorViewAppointments'
import PatientLogin  from './pages/patient/PatientLogin'
import PatientRegister  from './pages/patient/PatientRegister'
import PatientAppointmentHistory from './pages/patient/PatientAppointmentHistory'
import PatientViewPrescription from './pages/patient/PatientViewPrescription'
import AddPrescription from './pages/AddPrescription'
import ViewDoctors from './pages/ViewDoctors'
import ViewPatients from './pages/ViewPatients'
import Footer from './components/Footer'

import { ToastContainer, toast } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';
function App() {

  return (
    <>
      <Header />
     < Sidebar />
    <Footer />
     <AllRoutes/>
    <AdminLogin/>
<AdminAddDoctor/>
<DoctorViewAppointments/>
<PatientLogin/>
<PatientAppointmentHistory/>
<PatientRegister/>
<AddPrescription/>
<PatientViewPrescription/>
<ViewDoctors/>
<ViewPatients/>

<ToastContainer/>

    </>
  )
}

export default App
