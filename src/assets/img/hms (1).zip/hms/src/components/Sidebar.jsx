import React from 'react'

function Sidebar() {
  return (
    <>
    <nav className="pc-sidebar">
    <div className="navbar-wrapper">
      <div className="m-header">
        <a href="index.html" className="b-brand">
          {/* ========   Change your logo from here   ============ */}
          <img src="../assets/images/logo-dark.svg" alt className="logo logo-lg" />
        </a>
      </div>
      <div className="navbar-content">
        <ul className="pc-navbar">
          <li className="pc-item pc-caption">
            <label>Dashboard</label>
            <i className="ti ti-dashboard" />
          </li>
          <li className="pc-item">
            <a href="../dashboard/index.html" className="pc-link"><span className="pc-micon"><i className="ti ti-dashboard" /></span><span className="pc-mtext">Dashboard</span></a>
          </li>
          <li className="pc-item pc-caption">
            <label>Pages</label>
            <i className="ti ti-news" />
          </li>
          <li className="pc-item pc-hasmenu">
            <a href="#!" className="pc-link"><span className="pc-micon"><i className="ti ti-key" /></span><span className="pc-mtext">Authentication</span><span className="pc-arrow"><i className="ti ti-chevron-right" /></span></a>
            <ul className="pc-submenu">
              <li className="pc-item"><a className="pc-link" target="_blank" href="../pages/login-v3.html">Login</a></li>
              <li className="pc-item"><a className="pc-link" target="_blank" href="../pages/register-v3.html">register</a></li>
            </ul>
          </li>
          <li className="pc-item pc-caption">
            <label>Elements</label>
            <i className="ti ti-apps" />
          </li>
          <li className="pc-item">
            <a href="../elements/bc_typography.html" className="pc-link"><span className="pc-micon"><i className="ti ti-typography" /></span><span className="pc-mtext">Typography</span></a>
          </li>
          <li className="pc-item">
            <a href="../elements/bc_color.html" className="pc-link"><span className="pc-micon"><i className="ti ti-brush" /></span><span className="pc-mtext">Color</span></a>
          </li>
          <li className="pc-item">
            <a href="https://tablericons.com" className="pc-link" target="_blank"><span className="pc-micon"><i className="ti ti-plant-2" /></span><span className="pc-mtext">Tabler</span><span className="pc-arrow" /></a>
          </li>
          <li className="pc-item pc-caption">
            <label>Other</label>
            <i className="ti ti-brand-chrome" />
          </li>
          <li className="pc-item"><a href="../other/sample-page.html" className="pc-link"><span className="pc-micon"><i className="ti ti-brand-chrome" /></span><span className="pc-mtext">Sample page</span></a></li>
          <li className="pc-item"><a href="https://codedthemes.gitbook.io/berry-bootstrap/" target="_blank" className="pc-link"><span className="pc-micon"><i className="ti ti-vocabulary" /></span><span className="pc-mtext">Document</span></a></li>
        </ul>
        <div className="pc-navbar-card bg-primary rounded">
          <h4 className="text-white">Berry Pro</h4>
          <p className="text-white opacity-75">Checkout Berry pro features</p>
          <a href="https://codedthemes.com/item/berry-bootstrap-5-admin-template/" target="_blank" className="btn btn-light text-primary">Pro</a>
        </div>
      </div>
    </div>
  </nav>
    </>
  )
}

export default Sidebar