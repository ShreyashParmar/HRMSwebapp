import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore";
import {getAuth} from "firebase/auth";


const firebaseConfig = {
  apiKey: "AIzaSyBGB7y0582AQpbK2uwHZoEXsaFZnmTWWiE",
  authDomain: "hospital-management-c63c0.firebaseapp.com",
  projectId: "hospital-management-c63c0",
  storageBucket: "hospital-management-c63c0.appspot.com",
  messagingSenderId: "1028078503103",
  appId: "1:1028078503103:web:8dbc4ae7365d167c3b720a"
};


const app = initializeApp(firebaseConfig);

export let auth = getAuth()
export let db = getFirestore()